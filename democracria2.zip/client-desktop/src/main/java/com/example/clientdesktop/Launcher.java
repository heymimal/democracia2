package com.example.clientdesktop;

public class Launcher {
    public static void main(String[] args) {
        JavaFxApp.main(args);
    }
}
