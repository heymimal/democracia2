package com.example.clientdesktop.models;

public enum Voto {
    FAVORAVEL,

    DESFAVORAVEL,

    SEMVOTO
}
