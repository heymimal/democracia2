cd client-desktop
mvn clean javafx:run
