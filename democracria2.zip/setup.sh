# Requires Python and Pip

pip install pre-commit
pre-commit install
