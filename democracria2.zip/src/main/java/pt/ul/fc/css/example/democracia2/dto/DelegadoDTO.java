package pt.ul.fc.css.example.democracia2.dto;

public class DelegadoDTO extends CidadaoDTO{


    public DelegadoDTO(){
        super();
    }

    public DelegadoDTO(Long id, String nome, String apelido) {
        super(id, nome, apelido);
    }

}
