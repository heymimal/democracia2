package pt.ul.fc.css.example.democracia2.entities;

public enum Voto {
    FAVORAVEL,
    DESFAVORAVEL,
    SEMVOTO
}
