package pt.ul.fc.css.example.democracia2.exception;

public class ApplicationException extends Exception {
    public ApplicationException(String message) {
        super(message);
    }
}
