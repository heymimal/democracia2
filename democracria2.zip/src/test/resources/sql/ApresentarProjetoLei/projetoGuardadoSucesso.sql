INSERT INTO TEMA (id, nome)
VALUES (1, 'Geral');

INSERT INTO CIDADAO (id, dtype, nome, apelido)
VALUES(1,'Delegado', 'Tomas', 'Delegado');

