INSERT INTO CIDADAO (id, nome, apelido, dtype)
VALUES (1, "Manuel", "Joaquim", Delegado);

INSERT INTO TEMA (id, nome)
VALUES (1, "Geral");