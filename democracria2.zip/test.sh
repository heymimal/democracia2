docker build -t democracia_test . -f test.dockerfile
docker run democracia_test
